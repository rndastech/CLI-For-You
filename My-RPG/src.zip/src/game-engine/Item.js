// item class with (name , type , effect)
export default class Item {
    constructor(name, type, effect) {
      this.name = name;
      this.type = type;
      this.effect = effect;
    }
  }